from django.apps import AppConfig

class AbsenceConfig(AppConfig):
    name = 'Absence'
