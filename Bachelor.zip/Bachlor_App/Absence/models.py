from django.db import models
# Creaste your models here.
class Students(models.Model):
	dict ={'Nom':'',
		   'Prenom':'',
		   'Sexe':'',
		   'Adresse':'',
		   'Telephone':'',
		   'Email':'',
		   'filliere':'',
		   'Semestre':''
	}
	Nom = models.CharField(max_length = 250)
	Prenom =  models.CharField(max_length = 250)
	Sexe=models.CharField(max_length = 250)
	Adresse= models.CharField(max_length = 250, default='null')
	Telephone= models.CharField(null = True , max_length = 250)
	Email= models.EmailField(blank = True)	
	filliere = models.CharField(max_length = 250 ,default='null')
	Semestre = models.CharField(max_length = 250 ,default='null')
	def __str__(self):
		 return self.Nom+'-'+self.Prenom +'('+self.filliere+')' 
	
		