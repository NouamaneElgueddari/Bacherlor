from django.shortcuts import render
from django.http  import HttpResponse
from django.template import loader
from .models import Students


def Front_page(resquest):
    all_students = Students.objects.all()
    template = loader.get_template('Front_page.html')
    context = {
    'all_students' :all_students,  
    }
    return HttpResponse(template.render(context,resquest))
def Login(resquest):
    template = loader.get_template('Login.html')
    context = {
    }
    return HttpResponse(template.render(context,resquest))
def Charts(resquest):
    all_students = Students.objects.all()
    template = loader.get_template('Charts.html')
    context ={
    'all_students' :all_students,  
    }
    return HttpResponse(template.render(context,resquest))
def Tables(resquest):
    all_students = Students.objects.all()
    template = loader.get_template('tables.html')
    context ={
    'all_students' :all_students,  
    }
    return HttpResponse(template.render(context,resquest))                     