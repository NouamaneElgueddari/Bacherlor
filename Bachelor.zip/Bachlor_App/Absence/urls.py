from django.urls import re_path
from Student import views


urlpatterns = [
    re_path('^$', views.Front_page , name='Front_Page'),
    re_path('Charts/', views.Charts , name ='Charts'),
    re_path('Login/', views.Login , name ='login'),
    re_path('Tables/', views.Tables , name ='tables')
]

