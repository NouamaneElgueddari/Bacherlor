from django.contrib import admin
from Absence.models import Students

admin.site.register(Students)
